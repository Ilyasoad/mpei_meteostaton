<?php defined('SYSPATH') or die('No direct access allowed.');

class SSH_Exec extends Kohana_SSH_Exec {}
