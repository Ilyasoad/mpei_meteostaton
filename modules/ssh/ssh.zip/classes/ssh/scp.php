<?php defined('SYSPATH') or die('No direct access allowed.');

class SSH_SCP extends Kohana_SSH_SCP {}
