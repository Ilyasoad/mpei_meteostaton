<?php defined('SYSPATH') OR die('No direct access allowed.');

return array(

//	'ZIP_PROXY' => 'PclZipProxy',
//	'DELIMITER_LEFT' => '{',
//	'DELIMITER_RIGHT' => '}',
//	'PATH_TO_TMP' => null,
);
